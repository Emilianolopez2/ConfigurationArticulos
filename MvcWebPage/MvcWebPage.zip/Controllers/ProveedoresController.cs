﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Globalization;
using MvcWebPage.MLAVID;
using MvcWebPage.Data;
using NuGet.Protocol;
using System.Net.Mime;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using MvcWebPage.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Reflection;
using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using MvcWebPage.Services;


namespace MvcWebPage.Controllers
{
    [Authorize(Roles = "SUCURSAL")]
    public class ProveedoresController : Controller
    {
        public IActionResult GenerarPedidos()
        {
            ViewData["usuario"] = User.GetUserName();
            ViewData["sucursal"] = User.GetCodAlmacen();
            ViewData["lbSucursal"] = User.GetlbSucursal();
            ViewData["fecha"]   = DateTime.Now.ToString("dd/MM/yyyy");


            //MLAVIDContext db   = new DB();
            //var usuario = User.GetUserName();

            //var it=db.Procedures.IT_USUARIOSAsync().Result.FirstOrDefault(f=>f.NOMVENDEDOR==usuario);

            


            return View("GenerarPedidos/GenerarPedidos");
        }


        [HttpPost]
        public IActionResult GetDepartamentos([FromBody] Request req)
        {
            try
            {
                MLAVIDContext db = new MLAVID_DB();

                List<IT_PEDIDOS_CAB> sc = null;


                if (req.sucursal != "")
                {
                    sc = db.IT_PEDIDOS_CAB.Where(w => w.CODALMACEN == req.sucursal).ToList();
                }


                var rs = db.Procedures.IT_DEPARTAMENTOAsync(req.sucursal).Result
                    .Select(s => new IT_DEPARTAMENTOResult() 
                    {
                        DESCRIPCION = s.DESCRIPCION,
                        NUMDPTO     = s.NUMDPTO,
                        MODIFICADO = GetModificado(sc ,s),
                        ESTATUS = GetEstatus(sc ,s),
                        
                        
                    }).ToList();

                //s[0].MODIFICADO = 1;

                return new { code = 0, rs }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1,rs="[]",  msg=e.Message }.RSon();
            }

        }

        private int GetModificado(List<IT_PEDIDOS_CAB> sc, IT_DEPARTAMENTOResult s)
        {
            if (sc != null)
            {
                var it=sc.FirstOrDefault(f => f.NUMDPTO == s.NUMDPTO && f.FECHA != null && f.FECHA.Value.Date == DateTime.Now.Date && f.ESTATUS == 1);
                if (it != null)
                {
                    return it.MODIFICADO.Int32();
                }
            }


            return 0;
        }

        private int GetEstatus(List<IT_PEDIDOS_CAB> sc, IT_DEPARTAMENTOResult s)
        {
            if (sc != null)
            {
                var it = sc.FirstOrDefault(f => f.NUMDPTO == s.NUMDPTO && f.FECHA != null && f.FECHA.Value.Date == DateTime.Now.Date && f.ESTATUS == 1);
                if (it != null)
                {
                    return it.ESTATUS.Int32();
                }
            }


            return 0;
        }


        [HttpPost]
        public IActionResult GetDptoData([FromBody] Request req)
        {
            try
            {
                MLAVIDContext db = new MLAVID_DB();


                int year  = DateTime.Now.Year;
                int month = DateTime.Now.Month;
                int day   = DateTime.Now.Day;

                if (!string.IsNullOrEmpty(req.fecha))
                {
                    year  = DateTime.Parse(req.fecha).Year;
                    month = DateTime.Parse(req.fecha).Month;
                    day   = DateTime.Parse(req.fecha).Day;
                }

                var rs = db.Procedures.IT_PEDIDOSAsync(
                    req.sucursal, 
                    req.numdpto,
                    year,
                    month,
                    day).Result.ToList();


                
                if (req.excluir)
                {
                    rs.RemoveAll(r => r.CANTIDAD == null || r.CANTIDAD == 0);
                }


                foreach (var it in rs)
                {

                    /*
                    if (it.REFPROVEEDOR == "VER046-M")
                    {
                        it.MULTIPLOPEDIR = 3;
                    }

                    if (it.REFPROVEEDOR == "VER045-M")
                    {
                        it.MULTIPLOPEDIR = 5;
                    }
                    if (it.REFPROVEEDOR == "VER067-M")
                    {
                        it.MULTIPLOPEDIR = 2;
                    }
                    */

                    if (it.SUGERIDO == null)
                    {
                        it.SUGERIDO = 0;
                    }


                    if (it.MULTIPLOPEDIR == null)
                    {
                        it.MULTIPLOPEDIR = 0;
                    }



                    /*****************************************************/
                    var cal1 = (it.SUGERIDO.Value / it.MULTIPLOPEDIR.Value);
                    it.SUGERIDO = Math.Round(cal1) * it.MULTIPLOPEDIR;


                    /****************************************************/


                    it.SUGERIDO3 = it.SUGERIDO3.Str().Truncate(2).Dbl();
                    //it.SUGERIDO_COPIA = it.SUGERIDO_COPIA.Str().Truncate(2).Dbl();

                    if (it.CANTIDAD == null)
                    {

                        if (it.SUGERIDO != 0)
                        {
                            if (it.CANTIDAD_PEDIDA > it.SUGERIDO)
                            {
                                it.COLOR = 2;
                            }

                            if (it.CANTIDAD_PEDIDA < it.SUGERIDO)
                            {
                                it.COLOR = 1;
                            }
                        }
                    }
                    else
                    {
                        if (it.SUGERIDO != 0)
                        {
                            if (it.CANTIDAD > it.SUGERIDO)
                            {
                                it.COLOR = 2;
                            }

                            if (it.CANTIDAD < it.SUGERIDO)
                            {
                                it.COLOR = 1;
                            }
                        }
                    }

                    

                    it.COLOR_TMP = it.COLOR;

                    if (it.CANTIDAD_PEDIDA == null)
                    {
                        it.CANTIDAD_PEDIDA = 0;
                    }

                    it.SUGERIDO2 = it.SUGERIDO  - it.CANTIDAD_PEDIDA;
                    if (it.SUGERIDO2 < 0)
                    {
                        it.SUGERIDO2 = 0;
                    }


                    if (it.CANTIDAD == null)
                    {
                        it.CANTIDAD = 0;
                    }

                    if (it.CANTIDAD == 0)
                    {
                        it.CANTIDAD = it.SUGERIDO2;

                    }
                }

                //if (req.act == 1)
                //{
                //    foreach (var it in rs)
                //    {



                //        //it.CANTIDAD_PEDIDA_TMP = it.CANTIDAD_PEDIDA;



                //       // it.CANTIDAD = it.SUGERIDO2;


                        
                //    }
                //}

                return new { code = 0, rs }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1, rs = "[]", msg = e.Message }.RSon();
            }

            
            
        }


        [HttpPost]
        public IActionResult SavePedidos([FromBody] Request req)
        {

            


            if (req == null)
            {
                return new { code = -1 }.RSon();
            }


            req.pedidos.RemoveAll(r => r.CANTIDAD == null || r.CANTIDAD == 0);


            /*if (req.pedidos.Count == 0)
            {
                return new { code = 1 }.RSon();
            }*/


            MLAVIDContext db = new MLAVID_DB();
            MLAVIDContext db2 = new MLAVID_DB();


            var id = db.IT_PEDIDOS_CAB.Select(s=>s.ID).DefaultIfEmpty().Max() + 1;

            var fecha = DateTime.Now;
            var hora = new TimeSpan(0, fecha.Hour, fecha.Minute, fecha.Second);


            if (!string.IsNullOrEmpty(req.fecha))
            {
                fecha = DateTime.Parse(req.fecha);
            }

            var cab = db.IT_PEDIDOS_CAB.FirstOrDefault(f =>
                f.FECHA == fecha && 
                f.CODALMACEN == req.sucursal && 
                f.NUMDPTO == req.numdpto &&
                f.ESTATUS == 1);

            if (cab != null)
            {

                var itp = db2.IT_PEDIDOS_LIN.Where(w => w.ID_CAB == cab.ID);

                var lin = itp.ToList();
                

                var result = lin.IntersectBy(req.pedidos.Select(x => new
                {
                    x.CANTIDAD,
                    x.REFERENCIA
                }), x => new
                {
                    x.CANTIDAD,
                    x.REFERENCIA
                }).ToList();


                if (result.Count != req.pedidos.Count)
                {
                    cab.MODIFICADO = 2;
                }

                itp.ExecuteDelete();
                foreach (var it in req.pedidos)
                {
                    db.IT_PEDIDOS_LIN.Add(new IT_PEDIDOS_LIN
                    {
                        ID_CAB      = cab.ID,
                        CODALMACEN  = req.sucursal,
                        CODARTICULO = it.CODARTICULO,
                        REFERENCIA  = it.REFERENCIA,
                        CANTIDAD    = it.CANTIDAD,
                        SUGERIDO    = it.SUGERIDO,
                        SEMAFORO    = it.COLOR,
                        CODFORMATO  = it.CODFORMATO
                    });
                }

                db.UpdateRange(db.IT_PEDIDOS_LIN);

                db.SaveChanges();



            }
            else
            {
                db.IT_PEDIDOS_CAB.Add(new IT_PEDIDOS_CAB
                {
                    ID         = id,
                    CODALMACEN = req.sucursal,
                    NUMDPTO    = req.numdpto,
                    ESTATUS    = 1,
                    FECHA      = fecha,
                    HORA       = hora,
                    MODIFICADO = 1,
                    CODVENDEDOR = Extensions.GetCodVendedor(User)
                });
                
                foreach (var it in req.pedidos)
                {
                    db.IT_PEDIDOS_LIN.Add(new IT_PEDIDOS_LIN
                    {
                        ID_CAB      = id,
                        CODALMACEN  = req.sucursal,
                        CODARTICULO = it.CODARTICULO,
                        REFERENCIA  = it.REFERENCIA,
                        CANTIDAD    = it.CANTIDAD,
                        SUGERIDO    = it.SUGERIDO,
                        SEMAFORO    = it.COLOR,
                        CODFORMATO  = it.CODFORMATO

                    });
                }

                db.SaveChanges();
            }

            return new { code = 0 }.RSon();

            /*

            if (req.pedidos.All(a => a.CANTIDAD.Dbl() == 0))
            {
                return new { code = 1 }.RSon();
            }


            MLAVIDContext db = new DB();
            MLAVIDContext db2 = new DB();

            var tmp = db2.IT_PEDIDOS_TMP.Where(w => w.CODALMACEN == req.sucursal && w.NUMDPTO == req.numdpto).ToList();


            var modificado = 1;
            foreach (var it in req.pedidos)
            {

                if (modificado == 1)
                {
                    var ch = tmp.FirstOrDefault(f => f.NUMDPTO == req.numdpto && f.CODALMACEN == req.sucursal
                    && f.REFPROVEEDOR == it.REFPROVEEDOR);

                    if (ch != null)
                    {
                        if (ch.CANTIDAD.Dbl() != it.CANTIDAD.Dbl())
                        {
                            modificado = 2;
                            break;
                        }
                        else
                        {
                            if (ch.MODIFICADO != null && ch.MODIFICADO == 2)
                            {
                                modificado = 2;
                                break;
                            }
                        }
                    }
                }

            }

            var now = DateTime.Now;

            //var fecha =DateOnly.FromDateTime(now);

            //var hora = TimeOnly.FromDateTime(now);
            var hora = new TimeSpan(0, now.Hour, now.Minute, now.Second);


            foreach (var it in req.pedidos)
            {

                db.IT_PEDIDOS_TMP.Add(new IT_PEDIDOS_TMP
                {
                    CODALMACEN   = req.sucursal,
                    REFPROVEEDOR = it.REFPROVEEDOR,
                    CANTIDAD     = it.CANTIDAD,
                    NUMDPTO      = req.numdpto,
                    MODIFICADO   = modificado,
                    FECHA        = now,
                    HORA         = hora
                });
            }



            //db.Truncate("IT_PEDIDOS_TMP");

            //db.IT_PEDIDOS_TMP.Truncate(); //.ExecuteDelete();

            db.UpdateRange(db.IT_PEDIDOS_TMP);
            
            db.SaveChanges();

            //db.VENDEDORES.ExecuteDelete();

            //db.IT_PEDIDOS_TMP.Where(w => w.CODALMACEN == "01").ExecuteDelete();
            

            return new{ code = 0 }.RSon();*/
        }

        [HttpPost]
        public IActionResult GetSucursales([FromBody] Request req)
        {
            try
            {
                MLAVIDContext db = new MLAVID_DB();

                var rs = db.ALMACEN.ToList();

                if (req.todos)
                {
                    rs.Insert(0,new ALMACEN
                    {
                        CODALMACEN = "",
                        NOMBREALMACEN = "TODOS"
                    });
                }

                rs.RemoveAll(a => a.CODALMACEN == "00");

                return new { code = 0, rs }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1, rs = "[]", msg = e.Message }.RSon();
            }
        }

        [HttpPost]
        public IActionResult GetPedidos([FromBody] Request req)
        {
            try
            {
                if (string.IsNullOrEmpty(req.sucursal))
                {
                    req.sucursal = "";
                }


                MLAVIDContext db = new MLAVID_DB();

                var rs = db.Procedures.IT_PEDIDOS_CAB2Async(req.sucursal).Result.Select(s=>
                    new
                    {
                        s.ID,
                        s.CODALMACEN,
                        s.SUCURSAL,
                        s.NUMDPTO,
                        s.DEPARTAMENTO,
                        s.FECHA,
                        DETALLE = "Pedido " + s.ID,
                        s.ESTATUS2,
                        s.ESTATUS,
                        REFERENCIA = s.REFERENCIA + " " + GetFecha1(s)
                                     
                    }).ToList();


                return new { code = 0, rs }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1, rs = "[]", msg = e.Message }.RSon();
            }
        }

        private string GetFecha1(IT_PEDIDOS_CAB2Result it)
        {
            var f = it.FECHA.Value;
            var h = it.HORA.Value;

            var fecha = new DateTime(f.Year, f.Month, f.Day, h.Hours, h.Minutes, h.Seconds);



            return fecha.ToString("MMM").TrimEnd(".").ToTitleCase() + fecha.ToString(" yyyy d hh:mm tt");


        }

        public IActionResult AnularPedido([FromBody] Request req)
        {
            try
            {
                MLAVIDContext db = new MLAVID_DB();

                var it = db.IT_PEDIDOS_CAB.Where(f => f.ID == req.id);
                it.ExecuteDelete();
                


                return new { code = 0 }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1,  msg = e.Message }.RSon();
            }
        }

        public IActionResult ProcesarPedidos([FromBody] Request req)
        {
            try
            {
                PedidosService.ProcesarPedidos(req,User);

                return new { code = 0 }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1, msg = e.Message }.RSon();
            }
        }

        [Authorize(Policy = "PedLibre")]
        public IActionResult Pagina1()
        {
            return View();
        }

        [Authorize(Policy = "PedModifica")]
        public IActionResult Pagina2()
        {
            return View();
        }

        [Authorize(Policy = "PedElimina")]
        public IActionResult Pagina3()
        {
            return View();
        }

        public IActionResult PedidosAutorizados()
        {

            ViewData["usuario"]    = User.GetUserName();
            ViewData["sucursal"]   = User.GetCodAlmacen();
            ViewData["lbSucursal"] = User.GetlbSucursal();
            ViewData["fecha"]      = DateTime.Now.ToString("dd/MM/yyyy");

            return View("PedidosAutorizados/PedidosAutorizados");
        }

        [HttpPost]
        public IActionResult GetProveedores()
        {
            try
            {
                MLAVIDContext db = new MLAVID_DB();
                
                var rs = db.PROVEEDORES.Select(s => s.NOMPROVEEDOR).ToList();
                

                return new { code = 0, rs }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1, rs = "[]", msg = e.Message }.RSon();
            }
        }

        [HttpPost]
        public IActionResult GetPedidosAutorizados([FromBody] Request req)
        {
            try
            {
                MLAVIDContext db = new MLAVID_DB();


                var f1 = DateTime.Parse(req.fecha1);
                var f2 = DateTime.Parse(req.fecha2);

                var rs = db.Procedures.IT_PEDIDOS_AUTAsync(
                    req.sucursal,
                    req.proveedor,
                    f1.Year, 
                    f1.Month, 
                    f1.Day,
                    f2.Year, 
                    f2.Month, 
                    f2.Day).Result.ToList();

                rs.ForEach(f =>
                {
                    if (f.FECHAPEDIDO != null)
                    {
                        f.ENTREGA_ESTIMADA = f.FECHAPEDIDO.Value.AddDays(1);
                    }

                    //f.NOMPROVEEDOR = "DISTRIBUIDORA ALIMENTICIA PARA HOTELES Y RESTAURANTES, S. DE R.L.";

                    switch (f.IDESTADO)
                    {
                        case 0:
                            f.ESTATUS = "Por Autorizar";
                            break;
                        case 1:
                            f.ESTATUS = "Rechazado";
                            break;
                        case 2:
                            f.ESTATUS = "Entrega Pendiente";
                            break;
                        case 3:
                            f.ESTATUS = "En Transito";
                            break;
                    }



                });



                return new { code = 0, rs }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1, rs = "[]", msg = e.Message }.RSon();
            }
        }



        [HttpPost]
        public IActionResult GetPedidosAutorizados2([FromBody] Request req)
        {
            try
            {
                MLAVIDContext db = new MLAVID_DB();


                var f1 = DateTime.Parse(req.fecha1);
                var f2 = DateTime.Parse(req.fecha2);

                var rs = db.Procedures.IT_PEDIDOS_AUTAsync(
                    req.sucursal,
                    req.proveedor,
                    f1.Year,
                    f1.Month,
                    f1.Day,
                    f2.Year,
                    f2.Month,
                    f2.Day).Result.Where(w=> req.estatus == null || w.IDESTADO == req.estatus).ToList();

                rs.ForEach(f =>
                {

                    switch (f.IDESTADO)
                    {
                        case 0:
                            f.ESTATUS = "Por Autorizar";
                            break;
                        case 1:
                            f.ESTATUS = "Rechazado";
                            break;
                        case 2:
                            f.ESTATUS = "Entrega Pendiente";
                            break;
                        case 3:
                            f.ESTATUS = "En Transito";
                            break;
                    }



                });



                return new { code = 0, rs }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1, rs = "[]", msg = e.Message }.RSon();
            }
        }

        [HttpPost]
        public IActionResult GetPedidosAutorizadosDet([FromBody] Request req)
        {
            try
            {
                MLAVIDContext db = new MLAVID_DB();


                var rs = db.Procedures.IT_PEDIDOS_AUT_DETAsync(
                    req.id,
                    req.numserie,
                    req.numpedido).Result.ToList();

                foreach (var it in rs)
                {

                    if (it.TOTIVA == null)
                    {
                        it.TOTIVA = 0;
                    }

                    if (it.TOTREQ == null)
                    {
                        it.TOTREQ = 0;
                    }

                    it.TOTAL = it.TOTIVA + it.TOTREQ + it.TOTALLINEA;
                }

                string monedaDesc = "";
                string monedaCot  = "";

                var prov = db.PROVEEDORES.FirstOrDefault(f => f.CODPROVEEDOR == req.codproveedor);

                if (prov != null && prov.CODMONEDA != null)
                {
                    var moneda = db.MONEDAS.FirstOrDefault(f => f.CODMONEDA == prov.CODMONEDA);
                    if (moneda != null)
                    {
                        monedaDesc = moneda.DESCRIPCION;
                        monedaCot = moneda.COTDEF.Str();
                    }

                }

                var rs2 = db.REM_FRONTS.Where(w => w.ALMACEN == req.sucursal).Select(s => new
                {
                    NOMBRE     = s.NOMBRE.Str(),
                    DIRECCION  = s.DIRECCION.Str(),
                    DIRECCION2 = s.DIRECCION2.Str(),
                    PROVINCIA  = s.PROVINCIA.Str(),
                    CODPOSTAL  = s.CODPOSTAL.Str(),
                    CIF        = s.CIF.Str(),
                    PAIS       = s.PAIS.Str()
                }).FirstOrDefault();



                var rs3 = db.PROVEEDORES.Where(w => w.CODPROVEEDOR == req.codproveedor).Select(s => new
                {
                    NOMPROVEEDOR = s.NOMPROVEEDOR.Str(),
                    DIRECCION1   = s.DIRECCION1.Str(),
                    DIRECCION2   = s.DIRECCION2.Str(),
                    PROVINCIA    = s.PROVINCIA.Str(),
                    CODPOSTAL    = s.CODPOSTAL.Str(),
                    CIF          = s.CIF.Str(),
                    PAIS         = s.PAIS.Str(),
                    TELEFONO1    = s.TELEFONO1.Str(),
                    TELEFONO2    = s.TELEFONO2.Str(),
                }).FirstOrDefault();



                return new { code = 0, rs, rs2, rs3, monedaDesc, monedaCot }.RSon();
            }
            catch (Exception e)
            {
                return new { code = -1, rs = "[]", msg = e.Message }.RSon();
            }
        }


        public IActionResult AutorizarPedidos()
        {
            ViewData["usuario"]    = User.GetUserName();
            ViewData["sucursal"]   = User.GetCodAlmacen();
            ViewData["lbSucursal"] = User.GetlbSucursal();
            ViewData["fecha"]      = DateTime.Now.ToString("dd/MM/yyyy");

            return View("AutorizarPedidos/AutorizarPedidos");
        }
    }
}
